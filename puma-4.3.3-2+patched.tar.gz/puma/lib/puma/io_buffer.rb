# frozen_string_literal: true

require 'puma/detect'
require 'puma/puma_http11'

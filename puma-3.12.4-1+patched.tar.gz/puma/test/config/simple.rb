pidfile "/tmp/jruby.pid"
switch_user "daemon", "daemon"

persistent_timeout "6"
first_data_timeout "3"

workers "2"
threads "4", "8"

worker_timeout "90"
worker_boot_timeout "120"
worker_shutdown_timeout "150"
